$(document).ready(function() {
  

    /* 1 / 11 */
   $("#collapse1").hide();
   $('#list-button-1').click(function() {
   $('#collapse1').fadeToggle(300);
           $("#collapse2, #collapse3, #collapse4, #collapse5,#collapse6, #collapse7, #collapse8, #collapse9, #collapse10, #collapse11").hide();

   });
 
   
   /* 2 / 11 */
     $("#collapse2").hide();
   $('#list-button-2').click(function() {
   $('#collapse2').fadeToggle(300);
        $("#collapse1, #collapse3, #collapse4, #collapse5,#collapse6, #collapse7, #collapse8, #collapse9, #collapse10, #collapse11").hide();

   });
   
   /* 3 / 11 */
    $("#collapse3").hide();
   $('#list-button-3').click(function() {
   $('#collapse3').fadeToggle(300);
           $("#collapse1, #collapse2, #collapse4, #collapse5,#collapse6, #collapse7, #collapse8, #collapse9, #collapse10, #collapse11").hide();

   });
   
     /* 4 / 11 */
    $("#collapse4").hide();
   $('#list-button-4').click(function() {
   $('#collapse4').fadeToggle(300);
   $("#collapse1, #collapse2, #collapse3, #collapse5,#collapse6, #collapse7, #collapse8, #collapse9, #collapse10, #collapse11").hide();

   });
   
     /* 5 / 11 */
    $("#collapse5").hide();
   $('#list-button-5').click(function() {
   $('#collapse5').fadeToggle(300);
           $("#collapse1, #collapse2, #collapse3, #collapse4,#collapse6, #collapse7, #collapse8, #collapse9, #collapse10, #collapse11").hide();

   });
   
     /* 6 / 11 */
    $("#collapse6").hide();
   $('#list-button-6').click(function() {
   $('#collapse6').fadeToggle(300);
           $("#collapse1, #collapse2, #collapse3, #collapse4,#collapse5, #collapse7, #collapse8, #collapse9, #collapse10, #collapse11").hide();

   });
   
     /* 7 / 11 */
    $("#collapse7").hide();
   $('#list-button-7').click(function() {
   $('#collapse7').fadeToggle(300);
              $("#collapse1, #collapse2, #collapse3, #collapse4,#collapse5, #collapse6, #collapse8, #collapse9, #collapse10, #collapse11").hide();

   });
   
     /* 8 / 11 */
    $("#collapse8").hide();
   $('#list-button-8').click(function() {
   $('#collapse8').fadeToggle(300);
              $("#collapse1, #collapse2, #collapse3, #collapse4,#collapse5, #collapse6, #collapse7, #collapse9, #collapse10, #collapse11").hide();

   });
   
     /* 9 / 11 */
    $("#collapse9").hide();
   $('#list-button-9').click(function() {
   $('#collapse9').fadeToggle(300);
   $("#collapse1, #collapse2, #collapse3, #collapse4,#collapse5, #collapse6, #collapse7, #collapse8, #collapse10, #collapse11").hide();
   });
   
     /* 10 / 11 */
    $("#collapse10").hide();
   $('#list-button-10').click(function() {
   $('#collapse10').fadeToggle(300);
   $("#collapse1, #collapse2, #collapse3, #collapse4,#collapse5, #collapse6, #collapse7, #collapse8, #collapse9, #collapse11").hide();
   });
   
     /* 11 / 11 */
    $("#collapse11").hide();
   $('#list-button-11').click(function() {
   $('#collapse11').fadeToggle(300);
   $("#collapse1, #collapse2, #collapse3, #collapse4,#collapse5, #collapse6, #collapse7, #collapse8, #collapse9, #collapse10").hide();
   });
   
   


});

 
