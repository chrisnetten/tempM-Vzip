var express = require('express');
var router = express.Router();
var passport = require('passport');
var nodemailer = require('nodemailer');
var bodyParser = require('body-parser');
var multer = require('multer');



var User = require('../models/user');
var Testimonials = require('../models/testimonials');
var Img = require('../models/img');
var Economy = require('../models/economy');
var Silver = require('../models/silver');
var Gold = require('../models/gold');
var Platinum = require('../models/platinum');

var upload = multer({ dest: './public/uploads' });

router.use(bodyParser.urlencoded({extended: true}));

router.use(bodyParser.json());


/* GET home page. */
router.get('/', function(req, res, next) {


 User.find(function(err, user) {
      Img.find(function(err, img) {
    if(err) {
      console.log(err);
      res.end(err);
    }
    else {
      res.render('index', {

        title: 'Blog Main Page',
        user : user,
        img : img,
        name : req.posts ? req.post.name : '',
        username: req.user ? req.user.username : ''
      });
    }
  });
});
});

router.post('/upload', upload.single('upl'), function(req,res){
	
     var img = new Img(req.body);
    
    
    Img.create({
     name: req.file.filename,
     ingredients: req.body.ingredients,
     price : req.body.price,
     itemName : req.body.itemName
    }, function(err, User) {
      if(err) {
        console.log(err);
        console.log(req.file);
        res.end(err);
      }
      else {
        res.redirect('/users/cooking')
      }
    });
});


/* Get Cleaning page */

router.get('/cleaning', function(req, res, next) {
 User.find(function(err, user) {
    if(err) {
      console.log(err);
      res.end(err);
    }
    else {
      res.render('cleaning', {

        title: 'Blog Main Page',
        user : user,
        name : req.posts ? req.post.name : '',
        username: req.user ? req.user.username : ''
      });
    }
  });
});


router.get('/cooking', function(req, res, next) {
 Img.find(function(err, img) {
     User.find(function(err, user) {
    if(err) {
      console.log(err);
      res.end(err);
    }
    else {
      res.render('cooking', {

        title: 'Cooking',
        img : img,
        user : user,
        name : req.posts ? req.post.name : '',
        username: req.user ? req.user.username : ''
      });
    }
  });
});
});



router.get('/party_staffing', function(req, res, next) {
User.find(function(err, user) {
    Economy.find(function(err, economy) {
            Silver.find(function(err, silver) {
                    Gold.find(function(err, gold) {
                            Platinum.find(function(err, platinum) {
    if(err) {
      console.log(err);
      res.end(err);
    }
    else {
      res.render('party_staffing', {

        title: 'Event Staffing',
        user : user,
        economy : economy,
        silver : silver ,
        gold : gold ,
        platinum : platinum,
        name : req.posts ? req.post.name : '',
        username: req.user ? req.user.username : ''
      });
    }
  });
});
});
});
});
});



router.get('/dress_codes', function(req, res, next) {
User.find(function(err, user) {
    if(err) {
      console.log(err);
      res.end(err);
    }
    else {
      res.render('dress_codes', {

        title: 'Dress Codes',
        user : user,
        name : req.posts ? req.post.name : '',
        username: req.user ? req.user.username : ''
      });
    }
  });
});

router.get('/contact', function(req, res, next) {
User.find(function(err, user) {
    if(err) {
      console.log(err);
      res.end(err);
    }
    else {
      res.render('contact', {

        title: 'Contact',
        user : user,
        name : req.posts ? req.post.name : '',
        username: req.user ? req.user.username : ''
      });
    }
  });
});

router.post('/send', function(req, res, next){
                  
    var transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: 'mavinquiries@gmail.com',
            pass: 'mavinquiries12'
        }
    });
    
    var mailOptions = {
        from: req.body.email,
        to: 'maidsandvalets@gmail.com',
        subject: 'Inquiry',
        text: 'You have a new inquiry from Name: ' +'\n'+ req.body.name +'\n' + ' Email: ' +'\n'+ req.body.email + '\n' + ' Message: ' +'\n'+ req.body.message,
        
    }
    
    transporter.sendMail(mailOptions, function(error, info){
        if(error){
            console.log(error);
            res.redirect('/contact');

        } else {
            console.log('Success Message Sent' + info.response);
            res.redirect('/contact');

        }
    });
});

router.get('/careers', function(req, res, next) {
User.find(function(err, user) {
    if(err) {
      console.log(err);
      res.end(err);
    }
    else {
      res.render('careers', {

        title: 'Careers',
        user : user,
        name : req.posts ? req.post.name : '',
        username: req.user ? req.user.username : ''
      });
    }
  });
});

router.post('/application', upload.array('orderfile', 2), function(req, res, next){
         
         
                  
    var transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
             user: 'mavinquiries@gmail.com',
            pass: 'mavinquiries12'
        }
    });
    
    var mailOptions = {
        from: req.body.email,
        to: 'maidsandvalets@gmail.com',
        subject: 'Inquiry',
       attachments:  [
          {
               filename: 'Application-Image.jpg',
              path: req.files[0].path
              },
    {
        filename: 'Resume.doc',
         path: req.files[1].path
         }
        ],
        text: 'You have a new inquiry'+ '\n' + 'Name:   '+ req.body.name + '\n' + 'Email:  ' + req.body.email + '\n' + 'Position:  ' + req.body.orderservices + '\n' + 'Message:    ' + req.body.message,
        
            
        
    }
 transporter.sendMail(mailOptions, function(error, info){
        if(error){
            console.log(error);
            res.redirect('/careers');

        } else {
            console.log('Success Message Sent' + info.response);
            res.redirect('/careers');
                    console.log(req.file);

        }
    });
});
router.get('/policies', function(req, res, next) {
User.find(function(err, user) {
    if(err) {
      console.log(err);
      res.end(err);
    }
    else {
      res.render('policies', {

        title: 'Policies',
        user : user,
        name : req.posts ? req.post.name : '',
        username: req.user ? req.user.username : ''
      });
    }
  });
});

router.get('/media-testimonials', function(req, res, next) {
 Testimonials.find(function(err, testimonials) {
     User.find(function(err, user) {
    if(err) {
      console.log(err);
      res.end(err);
    }
    else {
      res.render('media-testimonials', {
        title: 'Blog Main Page',
        testimonials : testimonials,
        user : user,
        name : req.posts ? req.post.name : '',
        username: req.user ? req.user.username : ''
      });
    }
  });
});
});

router.get('/admin-login', function(req, res, next) {
  res.render('admin-login', {
    title: 'Home', 
     messages: req.flash('loginMessage'),
    displayName: req.user ? req.user.displayName : ''
  })
});

router.post('/admin-login', passport.authenticate('loginLocal', {
  successRedirect: '/users',
  failerRedirect: 'index',
  failureFlash: true
}));


/* Registration (TEMP) */

router.get('/register', function(req, res, next) {
    if(!req.user) {
        res.render('register', {
            title: 'Register',
            messages: req.flash('loginMessage'),
            displayName: req.user ? req.user.displayName : ''
        
        
    });
    }
    else {
        return res.redirect('/users');
    }
});

/* POST signup data. */
router.post('/register', passport.authenticate('localRegistration', {
    //Success go to Profile Page / Fail go to Signup page
    successRedirect : '/users',
    failureRedirect : '/register',
    failureFlash : true
}));

router.get('/logout', function(req,res) {
    req.logout();
    res.redirect('/');
});

module.exports = router;
