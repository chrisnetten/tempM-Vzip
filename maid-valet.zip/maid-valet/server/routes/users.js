var express = require('express');
var passport = require('passport');
var router = express.Router();
var multer = require('multer');
var bodyParser = require('body-parser');

var User = require('../models/user');
var Testimonials = require('../models/testimonials');
var Img = require('../models/img');
var Economy = require('../models/economy');
var Silver= require('../models/silver');
var Gold = require('../models/gold');
var Platinum = require('../models/platinum');

router.use(bodyParser.json());

/* FUNCTION to check if user is authenticated */
function requireAuth(req,res,next) {
   
   //is user logged in
   if(!req.isAuthenticated()){
   return res.redirect('/admin-login');
}
next();
}

/* Render Users main page */
router.get('/', requireAuth, function (req, res, next) {
  User.find(function(err, users) {

    if(err) {
      console.log(err);
      res.end(err);
    }
    else{
      res.render('users/index', {
          title: 'Contact',
          users: users,
          displayName: req.user ? req.user.displayName : ''
          
          
      });
    }
    });
  });
  
  router.get('/testimonials', requireAuth, function(req, res, next){
    
    Testimonials.find(function(err, testimonials){
    if(err) {
      console.log(err);
      res.end(err);
    }
    else {
      //show edit view
      res.render('users/testimonials', {
        title: "Testimonials",
        testimonials : testimonials,
        displayName: req.user ? req.user.displayName : '',
                name: req.posts? req.posts.name : ''
        
        
      });
    }
    });
    
});

router.post('/testimonials', function (req, res, next) {
    var testimonials = new Testimonials(req.body);
    
    
    Testimonials.create({
     clientName: req.body.clientName,
     text: req.body.text
    }, function(err, User) {
      if(err) {
        console.log(err);
        res.end(err);
      }
      else {
        res.redirect('/users/testimonials')
      }
    });
});

router.get('/testimonials/:id', requireAuth, function(req, res, next){
  
  
  // use mongoose nad model to find the contact
    Testimonials.findById(req.params.id , function(err, testimonials){

    if(err) {
      console.log(err);
      res.end(err);
    }
    else {
      //show edit view
      res.render('users/testimonials-edit', {
        title: "Post",
        testimonials : testimonials,
        displayName: req.user ? req.user.displayName : '',
                name: req.posts? req.posts.name : ''
        
        
      });
    }
    });
  });
  
    router.post('/testimonials/:id', requireAuth, function(req, res, next) {
  var id = req.params.id;
  var testimonials = new Testimonials(req.body);
  testimonials._id = id;
  testimonials.updated = Date.now();
    
  // mongoose will do the update
  Testimonials.update({_id: id}, testimonials, function (err) {
    if(err) {
      console.log(err);
      res.end(err);
    }
    else {
      res.redirect('/users/testimonials');
    }
  });
  
   
});

 /* Delete the selected user */
 router.get('/testimonials/delete/:id', requireAuth, function (req, res, next) {
   var id = req.params.id;
   Testimonials.remove({_id: id}, function(err) {
     if(err) {
       console.log(err);
       res.end(err);
     }
     else {
       res.redirect('/users/testimonials');
     }
   });
   
 });
 // Get Cooking Admin Page
  router.get('/cooking', requireAuth, function(req, res, next){
    
    Img.find(function(err, img){
    if(err) {
      console.log(err);
      res.end(err);
    }
    else {
      //show edit view
      res.render('users/cooking', {
        title: "Cooking",
        img : img ,
        displayName: req.user ? req.user.displayName : '',
                name: req.posts? req.posts.name : ''
        
        
      });
    }
    });
    
});

// Find Menu Item
router.get('/cooking/:id', requireAuth, function(req, res, next){
  
  
  // use mongoose nad model to find the contact
    Img.findById(req.params.id , function(err, img){

    if(err) {
      console.log(err);
      res.end(err);
    }
    else {
      //show edit view
      res.render('users/cooking-edit', {
        title: "Post",
        img: img,
        displayName: req.user ? req.user.displayName : '',
                name: req.posts? req.posts.name : ''
        
        
      });
    }
    });
  });

// Edit Menu Item
    router.post('/cooking/:id', requireAuth,  function(req, res, next) {
  var id = req.params.id;
  var img = new Img(req.body);
  img._id = id;
  img.updated = Date.now();
    
  // mongoose will do the update
  Img.update({_id: id}, img, function (err) {
    if(err) {
      console.log(err);
      res.end(err);
    }
    else {
      res.redirect('/users/cooking');
    }
  });
    });
     
      /* Delete the selected user */
 router.get('/cooking/delete/:id', requireAuth, function (req, res, next) {
   var id = req.params.id;
   Img.remove({_id: id}, function(err) {
     if(err) {
       console.log(err);
       res.end(err);
     }
     else {
       res.redirect('/users/cooking');
     }
   });
   
 });

// Get Event Staffing Admin Page
  router.get('/event-staffing', requireAuth, function(req, res, next){
    
    Economy.find(function(err, economy){
            Silver.find(function(err, silver){
                            Gold.find(function(err, gold){
                                            Platinum.find(function(err, platinum){
    if(err) {
      console.log(err);
      res.end(err);
    }
    else {
      //show edit view
      res.render('users/event-staffing', {
        title: "Event Staffing",
        economy : economy ,
        silver : silver,
        gold : gold,
        platinum : platinum,
        displayName: req.user ? req.user.displayName : '',
                name: req.posts? req.posts.name : ''
        
        
      });
    }
    });
    });
});
});
});


 router.get('/economy/:id', requireAuth, function(req, res, next){
    
    Economy.find(function(err, economy){
    if(err) {
      console.log(err);
      res.end(err);
    }
    else {
      //show edit view
      res.render('users/economy', {
        title: "Economy",
        economy : economy ,
        displayName: req.user ? req.user.displayName : '',
                name: req.posts? req.posts.name : ''
        
        
      });
    }
    });
    
});

// Edit Menu Item
    router.post('/economy/:id', requireAuth,  function(req, res, next) {
  var id = req.params.id;
  var economy = new Economy(req.body);
  economy._id = id;
  economy.updated = Date.now();
    
  // mongoose will do the update
  Economy.update({_id: id}, economy, function (err) {
    if(err) {
      console.log(err);
      res.end(err);
    }
    else {
      res.redirect('/users/event-staffing');
    }
  });
    });

router.get('/silver/:id', requireAuth, function(req, res, next){
    
    Silver.find(function(err, silver){
    if(err) {
      console.log(err);
      res.end(err);
    }
    else {
      //show edit view
      res.render('users/silver', {
        title: "Silver",
        silver : silver ,
        displayName: req.user ? req.user.displayName : '',
                name: req.posts? req.posts.name : ''
        
        
      });
    }
    });
    
});

   router.post('/silver/:id', requireAuth,  function(req, res, next) {
  var id = req.params.id;
  var silver = new Silver(req.body);
  silver._id = id;
  silver.updated = Date.now();
    
  // mongoose will do the update
  Silver.update({_id: id}, silver, function (err) {
    if(err) {
      console.log(err);
      res.end(err);
    }
    else {
      res.redirect('/users/event-staffing');
    }
  });
    });


router.get('/gold/:id', requireAuth, function(req, res, next){
    
    Gold.find(function(err, gold){
    if(err) {
      console.log(err);
      res.end(err);
    }
    else {
      //show edit view
      res.render('users/gold', {
        title: "Gold",
        gold: gold ,
        displayName: req.user ? req.user.displayName : '',
                name: req.posts? req.posts.name : ''
        
        
      });
    }
    });
    
});


router.post('/gold/:id', requireAuth,  function(req, res, next) {
  var id = req.params.id;
  var gold = new Gold(req.body);
  gold._id = id;
  gold.updated = Date.now();
    
  // mongoose will do the update
  Gold.update({_id: id}, gold, function (err) {
    if(err) {
      console.log(err);
      res.end(err);
    }
    else {
      res.redirect('/users/event-staffing');
    }
  });
    });

router.get('/platinum/:id', requireAuth, function(req, res, next){
    
    Platinum.find(function(err, platinum){
    if(err) {
      console.log(err);
      res.end(err);
    }
    else {
      //show edit view
      res.render('users/platinum', {
        title: "Platinum",
        platinum: platinum ,
        displayName: req.user ? req.user.displayName : '',
                name: req.posts? req.posts.name : ''
        
        
      });
    }
    });
    
});

router.post('/platinum/:id', requireAuth,  function(req, res, next) {
  var id = req.params.id;
  var platinum = new Platinum(req.body);
  platinum._id = id;
  platinum.updated = Date.now();
    
  // mongoose will do the update
  Platinum.update({_id: id}, platinum, function (err) {
    if(err) {
      console.log(err);
      res.end(err);
    }
    else {
      res.redirect('/users/event-staffing');
    }
  });
    });



module.exports = router;
