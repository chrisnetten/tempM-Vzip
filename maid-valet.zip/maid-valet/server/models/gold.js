//Import mongoose and bcrypt

var mongoose = require('mongoose');

// alias for mongoose.Schema

var Schema = mongoose.Schema; // shortcut object

// Define user Schema

var GoldSchema = new Schema ( {
	intro: String,
    recmix: String,
    recing: String,
    garnish: String,
	created: {type: Date, default: Date.now},
	updated: {type: Date, default: Date.now}
	
	
},
{
	collection: 'gold'
});

 

module.exports = mongoose.model('Gold', GoldSchema);