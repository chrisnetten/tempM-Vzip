//Import mongoose and bcrypt

var mongoose = require('mongoose');

// alias for mongoose.Schema

var Schema = mongoose.Schema; // shortcut object

// Define user Schema

var TestimonialsSchema = new Schema ( {
	
	text: String,
	clientName: String,
	created: {type: Date, default: Date.now},
	updated: {type: Date, default: Date.now}
	
	
},
{
	collection: 'testimonials'
});

 

module.exports = mongoose.model('Testimonials', TestimonialsSchema);