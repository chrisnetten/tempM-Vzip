//Import mongoose and bcrypt

var mongoose = require('mongoose');

// alias for mongoose.Schema

var Schema = mongoose.Schema; // shortcut object

// Define user Schema

var EconomySchema = new Schema ( {
	intro: String,
    recmix: String,
    garnish: String,
	created: {type: Date, default: Date.now},
	updated: {type: Date, default: Date.now}
	
	
},
{
	collection: 'economy'
});

 

module.exports = mongoose.model('Economy', EconomySchema);