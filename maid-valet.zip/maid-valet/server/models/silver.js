//Import mongoose and bcrypt

var mongoose = require('mongoose');

// alias for mongoose.Schema

var Schema = mongoose.Schema; // shortcut object

// Define user Schema

var SilverSchema = new Schema ( {
	intro: String,
    recmix: String,
    garnish: String,
	created: {type: Date, default: Date.now},
	updated: {type: Date, default: Date.now}
	
	
},
{
	collection: 'silver'
});

 

module.exports = mongoose.model('Silver', SilverSchema);