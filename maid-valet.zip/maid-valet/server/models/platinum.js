//Import mongoose and bcrypt

var mongoose = require('mongoose');

// alias for mongoose.Schema

var Schema = mongoose.Schema; // shortcut object

// Define user Schema

var PlatinumSchema = new Schema ( {
	intro: String,
    recmix: String,
    recing: String,
    garnish: String,
	created: {type: Date, default: Date.now},
	updated: {type: Date, default: Date.now}
	
	
},
{
	collection: 'platinum'
});

 

module.exports = mongoose.model('Platinum', PlatinumSchema);