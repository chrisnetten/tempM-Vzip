//Import mongoose and bcrypt

var mongoose = require('mongoose');

// alias for mongoose.Schema

var Schema = mongoose.Schema; // shortcut object

// Define user Schema

var ImgSchema = new Schema ( {
	price: String,
    ingredients: String,
    itemName: String,
	name: String,
	created: {type: Date, default: Date.now},
	updated: {type: Date, default: Date.now}
	
	
},
{
	collection: 'img'
});

 

module.exports = mongoose.model('Img', ImgSchema);