module.exports = {

//LIVE	
'url' : 'mongodb://maidsvalets:maids1valets1@ds015750.mlab.com:15750/maidsvalets'


};